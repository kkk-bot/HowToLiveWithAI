#!/usr/bin/env python3
"""从 Markdown 生成离线 HTML、连续文字版和带书签的中文 PDF。"""
from pathlib import Path
import argparse, hashlib, html, json, re
from urllib.parse import urlsplit
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak, Table, TableStyle, KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
DOCS = ['AI基础知识与教学.md', 'AI时代的技能学习建议.md', '青年学习与行动建议.md', '讲义资料与核查.md', '办公任务验收练习.md', '来源记录.md', '首轮资料库.md', '社交平台资料.md', '资料采纳记录.md', '第二轮资料库.md', '求职与迁移练习.md', '第三轮资料库.md', 'AI辅助学习练习.md', '孙宇晨与邵艾伦对谈整理.md', '版权与使用说明.md']
FRONT_DOC_COUNT = 3
FRONT = ROOT/'docs/免责声明与阅读说明.md'
INTRO = ROOT/'docs/阅读路径与行动建议.md'
LINK = re.compile(r'\[([^\]]+)\]\(([^)]+)\)')
META = json.loads((ROOT/'project.json').read_text())

def sources():
    chapters = []
    ids = []
    for i, p in enumerate(sorted((ROOT/'book').glob('*.md')), 1):
        text = p.read_text()
        title = re.search(r'^# (.+)', text, re.M).group(1)
        pieces = re.split(r'(?=^### \d+\.\d+ )', text, flags=re.M)
        entries = []
        for block in pieces[1:]:
            m = re.match(r'### (\d+\.\d+) (.+)', block)
            eid, name = m.group(1), m.group(2)
            fields = dict(re.findall(r'^- ([^：\n]+)：(.*)$', block, re.M))
            required = ['第一步','适合谁','成本','可能换回什么','怎么验收','何时不用','依据类型','来源','核查状态']
            if any(k not in fields for k in required):
                raise ValueError(f'{p.name}: 第 {eid} 条字段不完整')
            entries.append({'id':eid,'title':name,'fields':fields,'text':block,'chapter':i})
            ids.append(eid)
        expected=[f'{i}.{j}' for j in range(1,len(entries)+1)]
        if [e['id'] for e in entries]!=expected:
            raise ValueError(f'{p.name}: 必须按章号与章内顺序连续编号：{expected}')
        chapters.append({'id':i,'path':p,'title':title,'entries':entries,'text':text})
    if len(set(ids))!=len(ids):
        raise ValueError('条号重复')
    return chapters

CHAPTERS = sources()
ENTRIES = [e for c in CHAPTERS for e in c['entries']]
PATHS = {str(c['path'].relative_to(ROOT)):f'#chapter-{c["id"]}' for c in CHAPTERS}
PATHS['docs/免责声明与阅读说明.md']='#disclaimer'
PATHS['docs/阅读路径与行动建议.md']='#reading-path'
PATHS.update({f'docs/{name}':f'#doc-{i}' for i,name in enumerate(DOCS,1)})

def href(url, base):
    if urlsplit(url).scheme in ['https','http','mailto']:
        return url
    if url.startswith('#'):
        return url
    file, _, anchor = url.partition('#')
    target = (base/file).resolve()
    try: key = str(target.relative_to(ROOT))
    except ValueError: return '#about'
    if anchor and key.startswith('docs/'):
        return '#'+anchor
    return PATHS.get(key, '#about')

def inline(text, base=ROOT, pdf=False):
    output = []; last = 0
    for m in LINK.finditer(text):
        output.append(html.escape(text[last:m.start()]))
        label, url = m.groups()
        dest = href(url,base)
        if pdf:
            output.append(f'<link href="{html.escape(url,quote=True)}" color="#235E67">{html.escape(label)}</link>' if url.startswith(('https://','http://')) else (f'<link href="{html.escape(dest,quote=True)}" color="#235E67">{html.escape(label)}</link>' if dest.startswith('#') and dest!='#about' else html.escape(label)))
        else:
            output.append(f'<a href="{html.escape(dest,quote=True)}">{html.escape(label)}</a>')
        last = m.end()
    output.append(html.escape(text[last:]))
    out = ''.join(output)
    out = re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',out)
    out = re.sub(r'`([^`]+)`',r'\1' if pdf else r'<code>\1</code>',out)
    return out

def blocks(text):
    lines=text.splitlines(); i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line or line.startswith('[←') or line.startswith('<!--'):
            i+=1; continue
        if line.startswith('<a id='):
            yield ('anchor',re.search(r'id="([^"]+)"',line).group(1));i+=1;continue
        if line.startswith('```'):
            chunk=[];i+=1
            while i<len(lines) and not lines[i].startswith('```'):
                chunk.append(lines[i]);i+=1
            yield ('code','\n'.join(chunk));i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',x.replace(' ','')) for x in cells):rows.append(cells)
                i+=1
            yield ('table',rows);continue
        heading=re.match(r'^(#{1,3}) (.+)',line)
        if heading:
            yield ('h'+str(len(heading.group(1))),heading.group(2));i+=1;continue
        if line.startswith('- '):yield ('li',line[2:]);i+=1;continue
        if line.startswith('> '):yield ('quote',line[2:]);i+=1;continue
        para=[line];i+=1
        while i<len(lines) and lines[i].strip() and not re.match(r'^(#|\||-|>|<a|```)',lines[i].strip()):
            para.append(lines[i].strip());i+=1
        yield ('p',' '.join(para))

def render_md(text,base):
    out=[]
    for kind,v in blocks(text):
        if kind=='anchor':out.append(f'<a id="{v}"></a>')
        elif kind=='table':
            out.append('<div class="table-scroll"><table>')
            for i,row in enumerate(v):
                tag='th' if i==0 else 'td'
                out.append('<tr>'+''.join(f'<{tag}>{inline(cell,base)}</{tag}>' for cell in row)+'</tr>')
            out.append('</table></div>')
        elif kind=='code':out.append('<pre>'+html.escape(v)+'</pre>')
        elif kind=='li':out.append('<p class="bullet">'+inline(v,base)+'</p>')
        elif kind=='quote':out.append('<blockquote>'+inline(v,base)+'</blockquote>')
        else:
            tag=kind if kind.startswith('h') else 'p'
            out.append(f'<{tag}>{inline(v,base)}</{tag}>')
    return '\n'.join(out)

CSS='''
:root{--ink:#1c2b36;--muted:#5a6a71;--teal:#235e67;--paper:#faf8f3;--line:#dddeda}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:125px}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.85 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif}a{color:var(--teal);text-underline-offset:4px}header{max-width:1050px;margin:auto;padding:55px 28px 30px}.eyebrow{font-size:12px;letter-spacing:2px;color:var(--teal);text-transform:uppercase}h1{font-size:42px;line-height:1.3;letter-spacing:-1px;margin:15px 0}header p{max-width:720px;color:var(--muted)}.meta{font-size:13px}.actions{display:flex;gap:10px;flex-wrap:wrap}.actions a,.actions button{border:1px solid var(--line);background:white;padding:8px 16px;border-radius:6px;color:var(--ink);font:inherit;text-decoration:none;cursor:pointer}.toolbar{position:sticky;top:0;background:#faf8f3f5;z-index:5;border-block:1px solid var(--line);padding:14px 24px}.controls{max-width:994px;margin:auto;display:flex;gap:12px;align-items:center;flex-wrap:wrap}input,select{font:inherit;min-width:0;border:1px solid #aebabe;padding:9px 12px;border-radius:5px;background:#fff;color:var(--ink)}input{flex:1}#count{font-size:13px;color:var(--muted)}main{max-width:1050px;margin:auto;padding:20px 28px 60px}.chapter{margin:35px 0 15px;border-bottom:2px solid var(--teal);padding-bottom:10px;font-size:25px}.entry{margin:0;padding:25px 0 30px;border-bottom:1px solid var(--line);scroll-margin-top:120px}.entry h3{font-size:22px;line-height:1.6;margin:0 0 16px}.number{color:var(--teal);font-size:14px;display:block;letter-spacing:1px}.entry p{margin:10px 0}.label{font-weight:600}.evidence{background:#eef2ee;padding:14px 18px;margin-top:18px;border-left:3px solid var(--teal);font-size:14px;color:#41545d}.evidence p{margin:5px 0}details{margin:18px 0}summary{cursor:pointer;font-weight:600;padding:12px 0}details[open] summary{border-bottom:1px solid var(--line)}.document{padding:10px 0}.document h1{font-size:28px}.document h2{font-size:22px}.document h3{font-size:19px}table{border-collapse:collapse;width:100%;font-size:14px}td,th{border-bottom:1px solid var(--line);padding:10px;text-align:left;vertical-align:top}th{background:#e8eeeb}.table-scroll{overflow-x:auto}.bullet{padding-left:18px;position:relative}.bullet:before{content:'•';position:absolute;left:0}blockquote{margin:15px 0;padding:12px 18px;border-left:3px solid var(--teal);background:#eef2ee}code,pre{background:#eef0ec;font-size:14px}pre{padding:14px;overflow:auto}footer{border-top:1px solid var(--line);padding:25px 28px;color:var(--muted);font-size:13px}#empty{padding:35px 0}.hidden{display:none!important}@media(max-width:650px){h1{font-size:31px}header{padding-top:32px}.entry h3{font-size:20px}main{padding-inline:20px}.toolbar{padding-inline:20px}select{width:100%}}@media print{body{background:#fff;font-size:10pt;line-height:1.7}header{padding:0}h1{font-size:28pt}.toolbar,.actions,.meta,#empty{display:none}main{padding:0;max-width:none}.chapter{break-before:page}.entry h3{break-after:avoid}[data-section].hidden,.entry.hidden{display:block!important}#empty{display:none!important}details{display:block}summary{display:none}a{color:inherit}footer{display:none}@page{size:A4;margin:18mm}}
'''
JS='''
const input=document.querySelector('#search'),select=document.querySelector('#chapter-filter');
const entries=[...document.querySelectorAll('.entry')];
const normalize=s=>s.normalize('NFKC').toLowerCase().replace(/\\s+/g,' ').trim();
function filter(){const terms=normalize(input.value).split(' ').filter(Boolean);let count=0;
for(const e of entries){const ok=(!select.value||e.dataset.chapter===select.value)&&terms.every(t=>normalize(e.textContent).includes(t));e.classList.toggle('hidden',!ok);if(ok)count++}
for(const c of document.querySelectorAll('[data-section]'))c.classList.toggle('hidden',![...c.querySelectorAll('.entry')].some(e=>!e.classList.contains('hidden')));
document.querySelector('#count').textContent=`${count} / ${entries.length} 条`;document.querySelector('#empty').classList.toggle('hidden',count>0);
const params=new URLSearchParams();if(input.value)params.set('q',input.value);if(select.value)params.set('chapter',select.value);try{history.replaceState(null,'',location.pathname+(params.size?'?'+params:'')+location.hash)}catch{}
}
const params=new URLSearchParams(location.search);input.value=params.get('q')||'';select.value=params.get('chapter')||'';input.addEventListener('input',filter);select.addEventListener('change',filter);filter();
document.querySelector('#reset').addEventListener('click',()=>{input.value='';select.value='';filter()});
let printState=null;
function preparePrint(){if(printState)return;printState=[...document.querySelectorAll('details')].map(d=>[d,d.open]);for(const [d] of printState)d.open=true}
function finishPrint(){if(!printState)return;for(const [d,open] of printState)d.open=open;printState=null}
window.addEventListener('beforeprint',preparePrint);window.addEventListener('afterprint',finishPrint);
document.querySelector('#print').addEventListener('click',()=>{preparePrint();window.print()});
function revealHash(){if(!location.hash)return;let target;try{target=document.getElementById(decodeURIComponent(location.hash.slice(1)))}catch{return}if(!target)return;input.value='';select.value='';filter();let p=target;while(p){if(p.tagName==='DETAILS')p.open=true;p=p.parentElement}requestAnimationFrame(()=>target.scrollIntoView())}
window.addEventListener('hashchange',revealHash);revealHash();
'''

def build_html():
    nav=''.join(f'<option value="{c["id"]}">第 {c["id"]} 章 · {html.escape(c["title"])}</option>' for c in CHAPTERS)
    body=[f'<details id="disclaimer"><summary>免责声明与阅读说明</summary><div class="document">{render_md(FRONT.read_text(),ROOT/"docs")}</div></details>', f'<details id="reading-path" open><summary>给年轻人的导读：认识 AI，减少焦虑，开始行动</summary><div class="document">{render_md(INTRO.read_text(),ROOT/"docs")}</div></details>', f'<details id="doc-1" open><summary>AI 基础知识与教学</summary><div class="document">{render_md((ROOT/"docs"/DOCS[0]).read_text(),ROOT/"docs")}</div></details>']
    body.append(f'<details id="doc-2" open><summary>普通人在 AI 时代应该学什么技能</summary><div class="document">{render_md((ROOT/"docs"/DOCS[1]).read_text(),ROOT/"docs")}</div></details>')
    body.append(f'<details id="doc-3" open><summary>年轻人在 AI 时代：怎样选择、学习与行动</summary><div class="document">{render_md((ROOT/"docs"/DOCS[2]).read_text(),ROOT/"docs")}</div></details>')
    for c in CHAPTERS:
        body.append(f'<section data-section><h2 class="chapter" id="chapter-{c["id"]}">第 {c["id"]} 章 · {html.escape(c["title"])}</h2>')
        for e in c['entries']:
            fields=e['fields'];primary=[];evidence=[]
            for key,val in fields.items():
                paragraph=f'<p><span class="label">{html.escape(key)}：</span>{inline(val,c["path"].parent)}</p>'
                (evidence if key in ['依据类型','依据说明','来源','更新日期','核查状态'] else primary).append(paragraph)
            body.append(f'<article class="entry" id="entry-{e["id"]}" data-chapter="{c["id"]}"><h3><span class="number">{e["id"]}</span>{html.escape(e["title"])}</h3>'+''.join(primary)+'<div class="evidence">'+''.join(evidence)+'</div></article>')
        body.append('</section>')
    body.append('<p id="empty" class="hidden">没有匹配的条目。试试更短的关键词，或清除章节筛选。</p><h2 class="chapter">练习与资料</h2>')
    for i,name in enumerate(DOCS,1):
        if i<=FRONT_DOC_COUNT:continue
        text=(ROOT/'docs'/name).read_text();title=text.splitlines()[0].lstrip('# ')
        body.append(f'<details id="doc-{i}"><summary>{html.escape(title)}</summary><div class="document">{render_md(text,(ROOT/"docs"))}</div></details>')
    page=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{META['title']}</title><style>{CSS}</style></head><body>
<header id="about"><div class="eyebrow">HOW TO LIVE WITH AI / 青年建议与基础教学</div><h1>{META['title']}</h1><p>{META['subtitle']}。用白话了解基础知识，讨论值得学什么、可以做什么，再选一个小练习尝试。</p><p class="meta">v{META['version']} · {META['date']} · {len(CHAPTERS)} 章 / {len(ENTRIES)} 条 · {META['status']}</p><blockquote class="disclaimer"><b>免责声明：学习参考。</b> {html.escape(META['disclaimer'])} <a href="#disclaimer">完整说明</a></blockquote><div class="actions"><a href="#reading-path">青年导读</a><a href="#doc-1">AI 基础教学</a><a href="#doc-2">学什么技能</a><a href="#doc-3">怎样开始行动</a><a href="{META['pdf']}">下载 PDF</a><a href="阅读全文.html">连续阅读</a><a href="{META['cover']}">封面图片</a><button id="print">打印 / 保存 PDF</button></div></header>
<div class="toolbar"><div class="controls"><input id="search" type="search" aria-label="搜索条目" placeholder="搜索任务、表格、学习、接单…"><select id="chapter-filter" aria-label="选择章节"><option value="">全部章节</option>{nav}</select><button id="reset">清除筛选</button><span id="count" aria-live="polite"></span></div></div>
<main>{''.join(body)}</main><footer>正文与练习为本项目编写。研究、官方规定与作者建议分别标注。组织方式参考 <a href="https://github.com/eternity4719/HowToLiveBetter">HowToLiveBetter</a> 与 <a href="https://github.com/kkk-bot/HowToGetAlong">HowToGetAlong</a>。原创内容采用 CC BY 4.0；第三方资料按原许可处理。</footer><script>{JS}</script></body></html>'''
    (ROOT/'index.html').write_text(page)
    continuous=page.replace('<body>','<body class="continuous">').replace('<style>', '<style>.continuous .toolbar{display:none}').replace('input.addEventListener', "document.querySelectorAll('details').forEach(d=>d.open=true);input.addEventListener")
    (ROOT/'阅读全文.html').write_text(continuous)
    return page

class GuideDoc(BaseDocTemplate):
    def afterFlowable(self,f):
        if isinstance(f,Paragraph) and getattr(f,'bookmark',None):
            key=f.bookmark;level=f.outline_level
            self.canv.bookmarkHorizontalAbsolute(key,self.frame._y+f.height)
            self.canv.addOutlineEntry(f.getPlainText(),key,level,False)
            if level==0:self.notify('TOCEntry',(0,f.getPlainText(),self.page,key))

def build_pdf(font,bold):
    pdfmetrics.registerFont(TTFont('Guide',font,subfontIndex=0))
    pdfmetrics.registerFont(TTFont('GuideBold',bold,subfontIndex=0))
    pdfmetrics.registerFontFamily('Guide',normal='Guide',bold='GuideBold',italic='Guide',boldItalic='GuideBold')
    styles={
      'p':ParagraphStyle('body',fontName='Guide',fontSize=10.5,leading=17,textColor=colors.HexColor('#1c2b36'),spaceAfter=7,wordWrap='CJK'),
      'h1':ParagraphStyle('chapter',fontName='GuideBold',fontSize=23,leading=32,spaceAfter=20,keepWithNext=True,textColor=colors.HexColor('#1c2b36'),wordWrap='CJK'),
      'h2':ParagraphStyle('section',fontName='GuideBold',fontSize=15,leading=23,spaceBefore=15,spaceAfter=10,keepWithNext=True,textColor=colors.HexColor('#235e67'),wordWrap='CJK'),
      'h3':ParagraphStyle('entry',fontName='GuideBold',fontSize=14,leading=22,spaceBefore=17,spaceAfter=10,keepWithNext=True,wordWrap='CJK'),
      'small':ParagraphStyle('small',fontName='Guide',fontSize=9,leading=14.8,spaceAfter=6,textColor=colors.HexColor('#51656c'),wordWrap='CJK'),
      'cell':ParagraphStyle('cell',fontName='Guide',fontSize=8.5,leading=13,wordWrap='CJK'),
    }
    w,h=A4;output=ROOT/META['pdf'];output.parent.mkdir(exist_ok=True)
    def decorate(canvas,doc):
        if doc.page==1:
            canvas.drawImage(str(ROOT/META['cover']),0,0,width=w,height=h,preserveAspectRatio=True,anchor='c')
            return
        canvas.saveState();canvas.setStrokeColor(colors.HexColor('#d6dfdc'));canvas.line(48,h-41,w-48,h-41)
        canvas.setFont('Guide',8);canvas.setFillColor(colors.HexColor('#5a6a71'));canvas.drawString(48,h-31,META['title'])
        canvas.drawRightString(w-48,28,f'v{META["version"]} · {META["date"]}  /  {doc.page}')
        canvas.restoreState()
    doc=GuideDoc(str(output),pagesize=A4,title=META['title'],author='HowToLiveWithAI',leftMargin=48,rightMargin=48,topMargin=61,bottomMargin=48)
    doc.addPageTemplates(PageTemplate(id='main',frames=[Frame(48,48,w-96,h-109,id='body',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=decorate))
    story=[]
    def p(text,style='p'):return Paragraph(inline(text,pdf=True),styles[style])
    story.extend([Spacer(1,h-111),PageBreak()])
    front=p('免责声明与阅读说明','h1');front.bookmark='disclaimer';front.outline_level=0;story.append(front)
    for kind,v in blocks(FRONT.read_text()):
        if kind=='h1':continue
        story.append(p(v,kind if kind in ['h2','h3'] else 'p'))
    story.append(PageBreak())
    toc_title=p('目录','h1');story.append(toc_title)
    toc=TableOfContents();toc.levelStyles=[ParagraphStyle('toc',fontName='Guide',fontSize=10.5,leading=20,spaceBefore=5,wordWrap='CJK')];story.extend([toc,PageBreak()])
    def heading(text,level,key):
        f=p(text,'h1' if level==0 else 'h3');f.bookmark=key;f.outline_level=level;return f
    story.append(heading('给年轻人的导读：认识 AI，减少焦虑，开始行动',0,'reading-path'))
    intro_group=[]
    for kind,v in blocks(INTRO.read_text()):
        if kind=='h1':continue
        if kind in ['h2','h3']:
            if intro_group:story.append(KeepTogether(intro_group));intro_group=[]
            if kind=='h3':intro_group=[p(v,kind)];continue
        flow=Paragraph(inline(('• ' if kind=='li' else '')+v,ROOT/'docs',pdf=True),styles[kind if kind=='h2' else 'p'])
        if intro_group:intro_group.append(flow)
        else:story.append(flow)
    if intro_group:story.append(KeepTogether(intro_group))
    story.append(PageBreak())
    for i,name in enumerate(DOCS,1):
        # Place the three introductory articles before the problem-specific chapters.
        if i==FRONT_DOC_COUNT+1:
            for c in CHAPTERS:
                story.append(heading(f'第 {c["id"]} 章 · {c["title"]}',0,f'chapter-{c["id"]}'))
                for e in c['entries']:
                    entry_story=[heading(f'{e["id"]} {e["title"]}',1,f'entry-{e["id"]}')]
                    for key,val in e['fields'].items():
                        style='small' if key in ['依据类型','依据说明','来源','更新日期','核查状态'] else 'p'
                        entry_story.append(Paragraph(f'<b>{html.escape(key)}：</b>{inline(val,c["path"].parent,pdf=True)}',styles[style]))
                    story.append(KeepTogether(entry_story))
                story.append(PageBreak())
        text=(ROOT/'docs'/name).read_text()
        # PDF already has a navigable contents page; the complete source index stays in HTML.
        if name in ['首轮资料库.md','社交平台资料.md','第二轮资料库.md','第三轮资料库.md']:
            text=re.sub(r'(?ms)^## (?:快速索引|索引)\n.*?(?=^## )','',text)
        doc_story=[]
        pending_anchor=None
        for kind,v in blocks(text):
            if kind=='anchor':pending_anchor=v;continue
            if kind=='h1':doc_story.append(heading(v,0,f'doc-{i}'))
            elif kind in ['h2','h3']:
                f=p(v,kind)
                if pending_anchor:
                    f=Paragraph(f'<a name="{pending_anchor}"/>'+inline(v,pdf=True),styles[kind]);pending_anchor=None
                doc_story.append(f)
            elif kind=='table':
                width=w-96;cols=max(len(r) for r in v)
                rows=[[Paragraph(inline(cell,ROOT/'docs',pdf=True),styles['cell']) for cell in row]+['']*(cols-len(row)) for row in v]
                table=Table(rows,colWidths=[width/cols]*cols,repeatRows=1,hAlign='LEFT')
                table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8eeeb')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,-1),0.4,colors.HexColor('#d6dfdc')),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
                doc_story.extend([table,Spacer(1,12)])
            elif kind=='code':doc_story.append(Paragraph(inline(v,ROOT/'docs',pdf=True).replace('\n','<br/>'),styles['small']))
            else:doc_story.append(Paragraph(inline(('• ' if kind=='li' else '')+v,ROOT/'docs',pdf=True),styles['p']))
        # Keep each source record or short exercise together, including its final status/link.
        group=[]
        section_lead=[]
        for flow in doc_story:
            if isinstance(flow,Paragraph) and flow.style.name in ['chapter','section','entry']:
                if group:story.append(KeepTogether(group));group=[]
                # Keep introductory section labels with their first complete subsection.
                if flow.style.name=='section' and (name in ['AI时代的技能学习建议.md','青年学习与行动建议.md'] or (name=='AI基础知识与教学.md' and (re.match(r'^\d+\.',flow.getPlainText()) or flow.getPlainText()=='本篇新增的官方资料'))):
                    section_lead.append(flow);continue
                if flow.style.name=='entry':
                    group=section_lead+[flow];section_lead=[];continue
            if section_lead:
                section_lead.append(flow);continue
            if group:group.append(flow)
            else:story.append(flow)
        if group:story.append(KeepTogether(group))
        if section_lead:story.append(KeepTogether(section_lead))
        if i<len(DOCS):story.append(PageBreak())
    doc.multiBuild(story)
    return output

def validate(page):
    manifest=json.loads((ROOT/'downloads/build-manifest.json').read_text())
    for name,digest in manifest['sources'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('源文件已变化，请重新生成：'+name)
    expected_outputs=['index.html','阅读全文.html','完整指南.md',META['pdf']]
    if set(manifest.get('outputs',{}))!=set(expected_outputs):raise ValueError('生成文件校验记录不完整，请重新生成')
    for name,digest in manifest['outputs'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('生成文件已变化，请重新生成：'+name)
    continuous=(ROOT/'阅读全文.html').read_text()
    if 'class="continuous"' not in continuous:raise ValueError('连续阅读版模式错误')
    if page.count('class="entry"')!=len(ENTRIES):raise ValueError('HTML 条目数量错误')
    ids=set(re.findall(r'\bid="([^"]+)"',page))
    if len(ids)!=len(re.findall(r'\bid="([^"]+)"',page)):raise ValueError('HTML ID 重复')
    for target in re.findall(r'href="([^"]+)"',page):
        target=html.unescape(target)
        if target.startswith('#') and target[1:] not in ids:raise ValueError('HTML 缺失锚点 '+target)
        if target.startswith(('https://','http://','mailto:','#')):continue
        if not (ROOT/target).exists():raise ValueError('HTML 缺失文件 '+target)
    reader=PdfReader(ROOT/META['pdf'])
    text='\n'.join(p.extract_text() or '' for p in reader.pages)
    if META['disclaimer'] not in html.unescape(page):raise ValueError('HTML 缺少免责声明摘要')
    if merged_md(FRONT) not in (ROOT/'完整指南.md').read_text():raise ValueError('合并 Markdown 免责声明不同步')
    if merged_md(INTRO) not in (ROOT/'完整指南.md').read_text():raise ValueError('合并 Markdown 青年导读不同步')
    if '给年轻人的导读：认识 AI，减少焦虑，开始行动' not in text:raise ValueError('PDF 缺少青年导读')
    if 'AI 基础知识与教学：从理解到第一次使用' not in text:raise ValueError('PDF 缺少基础教学')
    if '普通人在 AI 时代应该学什么技能' not in text:raise ValueError('PDF 缺少技能学习建议')
    if merged_md(ROOT/'docs'/DOCS[1]) not in (ROOT/'完整指南.md').read_text():raise ValueError('合并 Markdown 技能学习建议不同步')
    if page.index('id="doc-2"')>page.index('id="chapter-1"'):raise ValueError('HTML 技能建议未放在正文前')
    action_doc=merged_md(ROOT/'docs'/'青年学习与行动建议.md')
    if action_doc not in (ROOT/'完整指南.md').read_text():raise ValueError('合并 Markdown 青年行动建议不同步')
    if '年轻人在 AI 时代：怎样选择、学习与行动' not in text:raise ValueError('PDF 缺少青年行动建议')
    if page.index('id="doc-3"')>page.index('id="chapter-1"'):raise ValueError('HTML 青年行动建议未放在正文前')
    if META['subtitle'] not in html.unescape(page):raise ValueError('HTML 副标题不同步')
    for title in ['免责声明与阅读说明','版权与使用说明']:
        if title not in text:raise ValueError('PDF 缺少'+title)
    if reader.outline[0]['/Title']!='免责声明与阅读说明':raise ValueError('PDF 开篇说明书签错误')
    if reader.outline[-1]['/Title']!='版权与使用说明':raise ValueError('PDF 文末版权书签错误')
    for e in ENTRIES:
        if e['title'].replace(' ','') not in text.replace(' ','').replace('\n',''):raise ValueError('PDF 缺失条目 '+e['title'])
    def count_outline(items):return sum(count_outline(x) if isinstance(x,list) else 1 for x in items)
    entry_bookmarks=[item['/Title'] for group in reader.outline if isinstance(group,list) for item in group if not isinstance(item,list)]
    expected=[f'{e["id"]} {e["title"]}' for e in ENTRIES]
    if entry_bookmarks!=expected:raise ValueError('PDF 条目书签顺序错误')
    html_order=re.findall(r'<article class="entry" id="entry-(\d+\.\d+)"',page)
    if html_order!=[e['id'] for e in ENTRIES]:raise ValueError('HTML 条目顺序错误')
    outlines=count_outline(reader.outline)
    if outlines < len(CHAPTERS)+len(ENTRIES)+len(DOCS)+1:raise ValueError('PDF 书签不足')
    links=sum(1 for p in reader.pages for ref in p.get('/Annots',[]) if ref.get_object().get('/A',{}).get('/URI'))
    internal=sum(1 for p in reader.pages for ref in p.get('/Annots',[]) if ref.get_object().get('/Dest'))
    if internal==0:raise ValueError('PDF 没有内部阅读链接')
    if links==0:raise ValueError('PDF 没有来源链接')
    print(json.dumps({'chapters':len(CHAPTERS),'entries':len(ENTRIES),'pdf_pages':len(reader.pages),'bookmarks':outlines,'source_links':links,'internal_links':internal,'html_links':'通过'},ensure_ascii=False))

def merged_md(path):
    # The merged document lives at repository root, so resolve each source's links there.
    def rewrite(match):
        label,url=match.groups()
        if urlsplit(url).scheme or url.startswith('#'):return match.group(0)
        file,separator,anchor=url.partition('#')
        target=(path.parent/file).resolve()
        try:dest=target.relative_to(ROOT).as_posix()
        except ValueError:return match.group(0)
        return f'[{label}]({dest}'+(separator+anchor if separator else '')+')'
    return LINK.sub(rewrite,path.read_text())

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true');parser.add_argument('--font',default='/System/Library/Fonts/STHeiti Light.ttc');parser.add_argument('--bold-font',default='/System/Library/Fonts/STHeiti Medium.ttc');args=parser.parse_args()
    if args.check:validate((ROOT/'index.html').read_text());return
    page=build_html();build_pdf(args.font,args.bold_font)
    text=f'# {META["title"]}\n\nv{META["version"]} · {META["date"]}\n\n'+merged_md(FRONT)+'\n\n'+merged_md(INTRO)+'\n\n'+'\n\n'.join(merged_md(ROOT/'docs'/n) for n in DOCS[:FRONT_DOC_COUNT])+'\n\n'+ '\n\n'.join(merged_md(c['path']) for c in CHAPTERS)+'\n\n'+ '\n\n'.join(merged_md(ROOT/'docs'/n) for n in DOCS[FRONT_DOC_COUNT:])
    (ROOT/'完整指南.md').write_text(text)
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'project.json',ROOT/'tools/build_release.py',FRONT,INTRO,ROOT/META['cover']]+[c['path'] for c in CHAPTERS]+[ROOT/'docs'/n for n in DOCS]}
    outputs={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ['index.html','阅读全文.html','完整指南.md',META['pdf']]}
    (ROOT/'downloads'/'build-manifest.json').write_text(json.dumps({'version':META['version'],'date':META['date'],'sources':hashes,'outputs':outputs},ensure_ascii=False,indent=2))
    validate(page)

if __name__=='__main__':main()
